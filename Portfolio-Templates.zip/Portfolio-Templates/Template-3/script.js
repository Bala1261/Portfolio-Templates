document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("projects-search-input");
  const filterButtons = document.querySelectorAll(".filter-tag-btn");
  const projectCards = document.querySelectorAll(".project-item-card");

  let searchQuery = "";
  let activeTag = "all";

  // Filter projects helper
  function filterProjects() {
    projectCards.forEach(card => {
      const cardTags = card.getAttribute("data-tags") ? card.getAttribute("data-tags").split(",") : [];
      const title = card.querySelector(".project-item-title").textContent.toLowerCase();
      const desc = card.querySelector(".project-desc").textContent.toLowerCase();
      
      const matchesSearch = title.includes(searchQuery) || desc.includes(searchQuery);
      const matchesTag = activeTag === "all" || cardTags.includes(activeTag);

      if (matchesSearch && matchesTag) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }

  // Hook input search
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      searchQuery = e.target.value.toLowerCase();
      filterProjects();
    });
  }

  // Hook tags filtering
  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      
      activeTag = btn.getAttribute("data-tag");
      filterProjects();
    });
  });

  // Interactive Mouse Move Radial Glow (Linear/Framer style)
  const mainPrismCard = document.getElementById("profile-prism-card");
  document.addEventListener("mousemove", (e) => {
    const cards = document.querySelectorAll(".glass-card");
    cards.forEach(card => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.setProperty("--mouse-x", `${x}px`);
      card.style.setProperty("--mouse-y", `${y}px`);
    });
  });
});
