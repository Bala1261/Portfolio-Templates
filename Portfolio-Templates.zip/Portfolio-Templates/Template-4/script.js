document.addEventListener('DOMContentLoaded', () => {
  // 1. Live Telemetry Clock / Watch Ticks
  const calibratedText = document.querySelector('.calibrated-text');
  if (calibratedText) {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getUTCHours()).padStart(2, '0');
      const minutes = String(now.getUTCMinutes()).padStart(2, '0');
      const seconds = String(now.getUTCSeconds()).padStart(2, '0');
      calibratedText.textContent = `CALIBRATED : STAGE_05 // [${hours}:${minutes}:${seconds} UTC]`;
    };
    updateTime();
    setInterval(updateTime, 1000);
  }

  // 2. Skill Dial Circle Gauges
  const skillDials = document.querySelectorAll('.skill-dial');
  const circumference = 2 * Math.PI * 24; // 150.796
  
  skillDials.forEach(dial => {
    const percent = parseFloat(dial.getAttribute('data-percent')) || 0;
    const fillStroke = dial.querySelector('.dial-fill-stroke');
    if (fillStroke) {
      // Set initial state to empty
      fillStroke.style.strokeDasharray = `${circumference}`;
      fillStroke.style.strokeDashoffset = `${circumference}`;
      
      // Animate to final state after load
      setTimeout(() => {
        const offset = circumference - (percent / 100) * circumference;
        fillStroke.style.strokeDashoffset = offset;
      }, 150);
    }
  });

  // 3. Registry Log Search Filter
  const searchBar = document.getElementById('registry-search-bar');
  const projectsList = document.getElementById('registry-projects-list');
  
  if (searchBar && projectsList) {
    const items = projectsList.querySelectorAll('.registry-item');
    
    searchBar.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      
      items.forEach(item => {
        const title = (item.getAttribute('data-title') || '').toLowerCase();
        const desc = (item.getAttribute('data-desc') || '').toLowerCase();
        const itemText = item.textContent.toLowerCase();
        
        if (title.includes(query) || desc.includes(query) || itemText.includes(query)) {
          item.style.display = 'flex';
          // Optional fade-in animation
          item.style.opacity = '1';
        } else {
          item.style.display = 'none';
          item.style.opacity = '0';
        }
      });
    });
  }

  // 4. Interactive Bento Cell Mouse Glow Tracker
  const bentoCells = document.querySelectorAll('.bento-cell');
  bentoCells.forEach(cell => {
    cell.addEventListener('mousemove', (e) => {
      const rect = cell.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      cell.style.setProperty('--mouse-x', `${x}px`);
      cell.style.setProperty('--mouse-y', `${y}px`);
    });
  });
});
