document.addEventListener('DOMContentLoaded', () => {
  // Project Filtering Logic
  const filterButtons = document.querySelectorAll('#project-filters .filter-btn');
  const projectCards = document.querySelectorAll('.projects-grid .project-card');

  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      // 1. Manage Active Class on Buttons
      filterButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');

      // 2. Filter Cards
      const selectedTag = button.getAttribute('data-tag').toLowerCase().trim();

      projectCards.forEach(card => {
        const cardTagsAttr = card.getAttribute('data-tags') || '';
        const cardTags = cardTagsAttr.split(',').map(tag => tag.trim().toLowerCase());

        if (selectedTag === 'all' || cardTags.includes(selectedTag)) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'translateY(10px)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 300);
        }
      });
    });
  });

  // Smooth entry transitions on scroll (optional utility for extra premium feel)
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.15
  };

  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in-visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Apply to section containers and cards
  const animElements = document.querySelectorAll('.project-card, .diagnostics-panel, .timeline-item, .publications-card, .list-card');
  animElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(15px)';
    el.style.transition = 'opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
    observer.observe(el);
  });

  // Custom class animation trigger helper
  const styleSheet = document.createElement('style');
  styleSheet.textContent = `
    .fade-in-visible {
      opacity: 1 !important;
      transform: translateY(0) !important;
    }
  `;
  document.head.appendChild(styleSheet);
});
