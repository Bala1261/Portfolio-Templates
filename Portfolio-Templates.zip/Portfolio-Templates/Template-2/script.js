document.addEventListener("DOMContentLoaded", () => {
  const filterButtons = document.querySelectorAll(".filter-btn");
  const projectCards = document.querySelectorAll(".project-card");

  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      // Toggle active classes
      filterButtons.forEach(btn => btn.classList.remove("active"));
      button.classList.add("active");

      const tag = button.getAttribute("data-tag");

      projectCards.forEach(card => {
        const cardTags = card.getAttribute("data-tags") ? card.getAttribute("data-tags").split(",") : [];
        if (tag === "all" || cardTags.includes(tag)) {
          card.style.display = "flex";
        } else {
          card.style.display = "none";
        }
      });
    });
  });
});
